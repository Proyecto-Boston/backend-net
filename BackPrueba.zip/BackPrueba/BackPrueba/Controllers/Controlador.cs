﻿using Microsoft.AspNetCore.Mvc;
using MiReferencia;
using System.ServiceModel;

namespace BackPrueba.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Controlador : Controller
    {
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] user User)
        {
            if (string.IsNullOrEmpty(User.email) || string.IsNullOrEmpty(User.password))
            {
                BadRequest("Usuario incompleto");

            };

            var binding = new BasicHttpBinding();
            var endpoint = new EndpointAddress("http://localhost:1802/app");
            var client = new MiReferencia.ServiceClient(binding, endpoint);

            try
            {
                loginResponse response = await client.loginAsync(User);
                return Ok(new { response.@return });
            }
            catch (FaultException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            finally
            {
                if (client.State == CommunicationState.Faulted)
                {
                    client.Abort();
                }
                else
                {
                    client.Close();
                }
            }
        }
        [HttpPost]
        [Route("registro")]
        public async Task<IActionResult> Registro([FromBody] user User)
        {
            var binding = new BasicHttpBinding();
            var endpoint = new EndpointAddress("http://localhost:1802/app");
            var client = new MiReferencia.ServiceClient(binding, endpoint);

            try
            {
                registerResponse response = await client.registerAsync(User);

                
                if (response != null)
                {
                    
                    return Ok(new { response.@return });
                }
                else
                {
                    return BadRequest("El servicio no respondió correctamente.");
                }
            }
            catch (FaultException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            finally
            {
                if (client.State == CommunicationState.Faulted)
                {
                    client.Abort();
                }
                else
                {
                    client.Close();
                }
            }
        }
        [HttpPost]
        [Route("verificarSesion")]
        public async Task<IActionResult> VerifySession(string token)
        {
            var binding = new BasicHttpBinding();
            var endpoint = new EndpointAddress("http://localhost:1802/app");
            var client = new MiReferencia.ServiceClient(binding, endpoint);

            try
            {
                verifySessionResponse response = await client.verifySessionAsync(token);

                
                if (response != null)
                {
                    return Ok(new { response.@return });
                }
                else
                {
                    return BadRequest("El servicio no respondió correctamente.");
                }
            }
            catch (FaultException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            finally
            {
                if (client.State == CommunicationState.Faulted)
                {
                    client.Abort();
                }
                else
                {
                    client.Close();
                }
            }
        }

    }
}
